def add_one(number):
    return number + 1


if __name__ == "__main__":
    print("This is example.py")
